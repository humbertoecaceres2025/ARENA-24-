const STREAM_URL = "PEGAR_AQUI_LA_URL_DEL_STREAM_ZENOMEDIA";
const player = document.getElementById("player");
const listenBtn = document.getElementById("listenBtn");
const status = document.getElementById("status");

listenBtn.addEventListener("click", () => {
  if (STREAM_URL.includes("PEGAR_AQUI")) {
    status.textContent = "Configurá STREAM_URL en js/app.js con la URL pública de tu stream ZenoMedia.";
    return;
  }
  player.src = STREAM_URL;
  player.style.display = "block";
  player.play().then(() => {
    listenBtn.textContent = "■ DETENER TRANSMISIÓN";
    status.textContent = "Conectado a FM Arenas Online.";
  }).catch(() => {
    status.textContent = "Tocá reproducir en el reproductor para iniciar.";
  });
});

player.addEventListener("pause", () => listenBtn.textContent = "▶ ESCUCHAR EN VIVO");

document.getElementById("shareBtn").addEventListener("click", async () => {
  const data = {title:"FM Arenas Online", text:"Escuchá FM Arenas Online — ARENA 24", url:location.href};
  if (navigator.share) await navigator.share(data);
  else await navigator.clipboard.writeText(location.href);
});
